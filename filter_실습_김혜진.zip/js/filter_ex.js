$(function(){
  // 반복문이나 이런거 돌리려면 배열안에 넣어야함~~~ [ ]
  //빈 배열을 준비해 놓고 여기에 img들을 집어넣음~~


  const $imgs = $("#gallery img");    //이미지들
  const $search = $("#filter-search")    //검색창을 말함
  const cache = [];


  $imgs.each(function(){
    cache.push({                                //배열에다가 element와 text를 넣을것임
      element:this,                             //---> 배열에다 imgs를 넣을것임  (this: $imgs)
      text: this.alt.trim().toLowerCase()       //---> 배열의 text부분에는 imgs의 alt값을 넣을것임 (this:$imgs)
    })
  })

  $search.on("keyup",filter);                 //검색창에 입력을 하면 filter함수를 실행해라

  function filter(){
  const abc = this.value.trim().toLowerCase();   //this.value  ---> 검색창의 값을 말함!! (this:$search)
  
  cache.forEach(function(img){                //(img와 alt값이 들어있는) 배열을 반복하라
    let x = 0;
    if (abc) {                             //만약에 
      index = img.text.indexOf(abc);      //img의 text값(alt값)에서 abc값(검색창의 값)을 찾아라 (=indexOf) 그 값을 변수로 지정해라
    }
    img.element.style.display = (index === -1 ? "none" : "");  //이미지의 css에서 display값이 / index값이 -1이면 display:none, -1이 아니면 보이게
  })
}

  
})