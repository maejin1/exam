<?
           session_start();
?>
  <meta charset="utf-8">

<?

include "dbconn.php";       // dconn.php 파일을 불러옴
                             //form형식이 post이므로 여기 안에있는건 다 post로 받아야~~

$code = $_POST['code'];
$name = $_POST['name'];
$gubun = $_POST['gubun'];
$thing=$_POST['thing'];
$product=$_POST['product'];
$all=$_POST['all'];

     $sql = "insert into price (code,name,gubun,thing,product,all) values";
     $sql .= "('$code','$name','$gubun',$thing,$product,$all)";

     $result = mysqli_query( $connect,$sql);
 
    mysqli_close($connect);    // DB 접속 끊기
    echo "
    <script>
     location.href = 'pro_list.php';
    </script>
 ";
 
 ?>
  
 </table>
