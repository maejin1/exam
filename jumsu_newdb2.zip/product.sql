create table price (

	code varchar(5),
	name varchar(10),
	gubun varchar(1),
	thing int,
	product int,
	all int,


	primary key(code)
);