<?
 $connect=mysqli_connect( "localhost", "zhen4232", "t86dptmel#","zhen4232") or  
        die( "SQL server에 연결할 수 없습니다."); 

    mysqli_select_db($connect,"zhen4232");
//localhost, username,pw,dbname

//이거는 db에다가 연결시키는 거래~~~ (내 비밀번호 넣고~~)
?>
