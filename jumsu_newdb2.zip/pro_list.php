<?php
           session_start();
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
<style>

   tr,td {text-align:center;}
   table {padding:20px;box-sizing:border-box;}
   .tb {border:none;}
    tr, td {border:none;}
    
   </style>
<body>
<h3> 가격 입력하기</h3>

<form action="insert.php" method='post'>
<table width="720" border="1" cellpadding="5">
    <tr>
      <td> 제품코드 : <input type="text" size="6" name="code"> </td>
      <td> 제품명 : <input type="text" size="6" name="name"> </td>
      <td>구분 : <input type="text" size="6" name="gubun"> </td>
      <td> 수량 : <input type="text" size="6" name="thing"> </td>
      <td> 단가 : <input type="text" size="6" name="product"> </td>

       <td align="center">
	    <input type="submit" value="입력하기">	
       </td>
    </tr>
 </table>
 </form>

 <div>
<h3> 성적 출력 하기</h3>  
<p><a href ="pro_list.php?mode=big_first">[제품코드 내림차순정렬]</a> 
   <a href ="pro_list.php?mode=small_first">[제품코드 오름차순 정렬]</a></p>
   </div>
 <!-- 제목 표시 시작 -->
 <table width="720" border="1">
 <tr>
 <td>제품코드</td>
 <td>제품명</td>
 <td>구분</td>
 <td>수량</td>
 <td>단가</td>
 <td>금액</td>
 <td>DEL</td>
 </tr>
 <!-- 제목 표시 끝 -->
 
 <?
      include "dbconn.php"; 

      $mode = $_GET['mode'];
      $code = $_GET['code'];
      $name = $_POST['name'];
      $gubun = $_POST['gubun'];
      $thing=$_POST['thing'];
      $product=$_POST['product'];
      $all=$_POST['all'];




    if ($mode == "big_first")          // 성적순 정렬(내림차순)
       $sql = "select * from price order by name desc";
    else if ($mode == "small_first")   // 성적순 정렬(오름차순)
       $sql = "select * from price order by name";
    else 
       $sql = "select * from price";
 
       $result = mysqli_query( $connect,$sql);
 
                    
 
 // DB 데이터 출력 시작~~~~~~~~~~~~~~~~~~~
    while ($row = mysqli_fetch_array($result))
    {   
      // $avg = round($row['avg'], 1);
 
       $code = $row['code'];
       
       echo "<tr align='center'>
                <td> $count     </td>
       		<td> $row[code] </td>
             <td> $row[name] </td>
             <td> $row[gubun]</td>
             <td> $row[thing] </td>
             <td> $row[product] </td>
             <td> $row[all] </td>
       		 <td> <a href='pro_del.php?code=$code'>[삭제]</a></td>
	      </tr>
             ";
     

     }
 // DB 데이터 출력 끝

     mysqli_close($connect);                   // DB 접속 끊기
 ?>
  
 </table>


</body>
</html>